#ifndef _ROS_SERVICE_JointTrajectory_h
#define _ROS_SERVICE_JointTrajectory_h
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace faze4
{

static const char JOINTTRAJECTORY[] = "faze4/JointTrajectory";

  class JointTrajectoryRequest : public ros::Msg
  {
    public:
      typedef float _j1_position_type;
      _j1_position_type j1_position;
      typedef float _j2_position_type;
      _j2_position_type j2_position;
      typedef float _j3_position_type;
      _j3_position_type j3_position;
      typedef float _j4_position_type;
      _j4_position_type j4_position;
      typedef float _j5_position_type;
      _j5_position_type j5_position;
      typedef float _j6_position_type;
      _j6_position_type j6_position;

    JointTrajectoryRequest():
      j1_position(0),
      j2_position(0),
      j3_position(0),
      j4_position(0),
      j5_position(0),
      j6_position(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      offset += serializeAvrFloat64(outbuffer + offset, this->j1_position);
      offset += serializeAvrFloat64(outbuffer + offset, this->j2_position);
      offset += serializeAvrFloat64(outbuffer + offset, this->j3_position);
      offset += serializeAvrFloat64(outbuffer + offset, this->j4_position);
      offset += serializeAvrFloat64(outbuffer + offset, this->j5_position);
      offset += serializeAvrFloat64(outbuffer + offset, this->j6_position);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->j1_position));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->j2_position));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->j3_position));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->j4_position));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->j5_position));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->j6_position));
     return offset;
    }

    const char * getType(){ return JOINTTRAJECTORY; };
    const char * getMD5(){ return "b41d162a0e573510494475e33a1ca36c"; };

  };

  class JointTrajectoryResponse : public ros::Msg
  {
    public:
      typedef int64_t _sum_type;
      _sum_type sum;

    JointTrajectoryResponse():
      sum(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        int64_t real;
        uint64_t base;
      } u_sum;
      u_sum.real = this->sum;
      *(outbuffer + offset + 0) = (u_sum.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_sum.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_sum.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_sum.base >> (8 * 3)) & 0xFF;
      *(outbuffer + offset + 4) = (u_sum.base >> (8 * 4)) & 0xFF;
      *(outbuffer + offset + 5) = (u_sum.base >> (8 * 5)) & 0xFF;
      *(outbuffer + offset + 6) = (u_sum.base >> (8 * 6)) & 0xFF;
      *(outbuffer + offset + 7) = (u_sum.base >> (8 * 7)) & 0xFF;
      offset += sizeof(this->sum);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        int64_t real;
        uint64_t base;
      } u_sum;
      u_sum.base = 0;
      u_sum.base |= ((uint64_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_sum.base |= ((uint64_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_sum.base |= ((uint64_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_sum.base |= ((uint64_t) (*(inbuffer + offset + 3))) << (8 * 3);
      u_sum.base |= ((uint64_t) (*(inbuffer + offset + 4))) << (8 * 4);
      u_sum.base |= ((uint64_t) (*(inbuffer + offset + 5))) << (8 * 5);
      u_sum.base |= ((uint64_t) (*(inbuffer + offset + 6))) << (8 * 6);
      u_sum.base |= ((uint64_t) (*(inbuffer + offset + 7))) << (8 * 7);
      this->sum = u_sum.real;
      offset += sizeof(this->sum);
     return offset;
    }

    const char * getType(){ return JOINTTRAJECTORY; };
    const char * getMD5(){ return "b88405221c77b1878a3cbbfff53428d7"; };

  };

  class JointTrajectory {
    public:
    typedef JointTrajectoryRequest Request;
    typedef JointTrajectoryResponse Response;
  };

}
#endif
