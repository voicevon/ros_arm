#!/usr/bin/env python

#  The exlaination is here:
#  http://docs.ros.org/kinetic/api/moveit_tutorials/html/doc/move_group_python_interface/move_group_python_interface_tutorial.html

## To use the Python MoveIt! interfaces, we will import the `moveit_commander`_ namespace.
## This namespace provides us with a `MoveGroupCommander`_ class, a `PlanningSceneInterface`_ class,
## and a `RobotCommander`_ class. (More on these below)

# from common
import sys
from math import pi
import math
import numpy as np
from datetime import datetime
import time
# from ROS
import rospy
from std_msgs.msg import Empty
import geometry_msgs.msg
from sensor_msgs.msg import JointState
# from MoveIt!
import moveit_commander
from moveit_commander.conversions import pose_to_list
import moveit_msgs.msg

import cv2 as cv
from perfect_robot.msg import move_arm   # next version , name will be perfect_robot_command
from perfect_robot.msg import eef
from perfect_robot.msg import report

arm_is_synced = False
eef_msg = eef()
eef_msg.action = 0  # 1== suck  2= release
hand_in_world_x = 0
hand_in_world_y = 0
hand_in_world_z = 0.7

# eef_acktion = enumerate([EEF_SLEEP,EEF_PICK,EEF_PLACE])

def all_close(goal, actual, tolerance):
  """
  Convenience method for testing if a list of values are within a tolerance of their counterparts in another list
  @param: goal       A list of floats, a Pose or a PoseStamped
  @param: actual     A list of floats, a Pose or a PoseStamped
  @param: tolerance  A float
  @returns: bool
  """
  all_equal = True
  if type(goal) is list:
    for index in range(len(goal)):
      if abs(actual[index] - goal[index]) > tolerance:
        return False

  elif type(goal) is geometry_msgs.msg.PoseStamped:
    return all_close(goal.pose, actual.pose, tolerance)

  elif type(goal) is geometry_msgs.msg.Pose:
    return all_close(pose_to_list(goal), pose_to_list(actual), tolerance)

  return True

# a = ["home","view_checkerboard", "pick_chessman"]
# b = ["pick","place"]
# fixed_poses = enumerate(a)
# ACTION = enumerate(b)
# do_suck = False
'''  '''

class MoveGroupPythonIntefaceTutorial(object):
  """MoveGroupPythonIntefaceTutorial"""
  def __init__(self):
    super(MoveGroupPythonIntefaceTutorial, self).__init__()    # https://stackoverflow.com/questions/576169/understanding-python-super-with-init-methods

    ## First initialize `moveit_commander`_ and a `rospy`_ node:
    moveit_commander.roscpp_initialize(sys.argv)
    # rospy.init_node('move_group_python_interface_tutorial', anonymous=True)

    ## Instantiate a `RobotCommander`_ object. 
    # This object is the outer-level interface to the robot:
    robot = moveit_commander.RobotCommander()

    ## Instantiate a `PlanningSceneInterface`_ object.  
    # This object is an interface to the world surrounding the robot:
    scene = moveit_commander.PlanningSceneInterface()

    ## Instantiate a `MoveGroupCommander`_ object.  
    # This object is an interface to one group of joints.  
    # In this case the group is the joints in the MARA's arm so we set ``group_name = manipulator``. 
    # If you are using a different robot, you should change this value to the name of your robot arm planning group.
    ## This interface can be used to plan and execute motions on the MARA:
    group_name = "arm"
    group = moveit_commander.MoveGroupCommander(group_name)

    ## We create a `DisplayTrajectory`_ publisher which is used later to publish
    ## trajectories for RViz to visualize:
    display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',
                                                   moveit_msgs.msg.DisplayTrajectory,
                                                   queue_size=20)

    ## Getting Basic Information
    ## ^^^^^^^^^^^^^^^^^^^^^^^^^
    planning_frame = group.get_planning_frame()
    eef_link = group.get_end_effector_link()
    group_names = robot.get_group_names()

    # print "============ Reference frame: %s" % planning_frame
    # print "============ End effector: %s" % eef_link
    # print "============ Robot Groups:", robot.get_group_names()
    # print "============ Printing robot state",robot.get_current_state()

    # Misc variables
    self.box_name = ''
    self.robot = robot
    self.scene = scene
    self.group = group
    self.display_trajectory_publisher = display_trajectory_publisher
    self.planning_frame = planning_frame
    self.eef_link = eef_link
    self.group_names = group_names

  def go_to_joint_state(self):
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good reason not to.
    group = self.group

    ## Planning to a Joint Goal   ?? Is this function being involked??
    ## ^^^^^^^^^^^^^^^^^^^^^^^^ 
    ## MARA's zero configuration is at a `singularity <https://www.quora.com/Robotics-What-is-meant-by-kinematic-singularity>`_ 
    # so the first thing we want to do is move it to a slightly better configuration.
    # We can get the joint values from the group and adjust some of the values:
    joint_goal = group.get_current_joint_values()
    joint_goal[0] = 0
    joint_goal[1] = -pi/8
    joint_goal[2] = 0
    joint_goal[3] = -pi/4
    joint_goal[4] = 0
  

    # The go command can be called with joint values, poses, or without any
    # parameters if you have already set the pose or joint target for the group
    group.go(joint_goal, wait=True)

    # Calling ``stop()`` ensures that there is no residual movement
    group.stop()

    ## END_SUB_TUTORIAL

    # For testing:
    # Note that since this section of code will not be included in the tutorials
    # we use the class variable rather than the copied state variable
    current_joints = self.group.get_current_joint_values()
    current_pose = self.group.get_current_pose().pose
    print "=================>>>>>>>>>>>>>>>",current_pose
    return all_close(joint_goal, current_joints, 0.01)

  def create_pose_with_head_up(self,x,y,z):
    target_pose = geometry_msgs.msg.Pose()

    target_pose.orientation.x = 0.707
    target_pose.orientation.y = 0.707
    target_pose.orientation.z = 0
    target_pose.orientation.w = 0

    target_pose.position.x = x
    target_pose.position.y = y
    target_pose.position.z = z
    return target_pose

  def create_pose_with_head_down(self,x,y,z):
    target_pose = self.group.get_random_pose()

    target_pose.pose.orientation.x = 1
    target_pose.pose.orientation.y = 0
    target_pose.pose.orientation.z = 0
    target_pose.pose.orientation.w = 0

    target_pose.pose.position.x = x
    target_pose.pose.position.y = y
    target_pose.pose.position.z = z

    return target_pose
  
  def app_goto_position(self,x,y,z):
    target_pose = None
    if z > 0.4:
      target_pose = self.create_pose_with_head_up(x,y,z)
    else:
      target_pose = self.create_orientation_with_head_down(x,y,z)
    self.go_to_pose_goal(target_pose)

  def app_goto_position(self,to_where):
    if pose_name == fixed_poses.home:
      target_pose.position=[0,0,0]
      target_pose.oreintation=[0,0,0,0]
      self.go_to_pose_goal(target_pose)

  def app_pick_place(self,action):
    if action == ACTION.pick:
      publisher.publish("pick")
    else:
      publisher.publish("place")

  def app_get_current_position(self):
    x = self.group.GetCurrentPose().position.x
    y = self.group.GetCurrentPose().position.y
    z = self.group.GetCurrentPose().position.z
    return x,y,z

  def go_to_pose_goal(self,target_pose,wait_for_syncing):
    global arm_is_synced
    global hand_in_world_x
    global hand_in_world_y
    global hand_in_world_z
    
    # print 'go_to_pose_goal() begin...'
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good reason not to.
    group = self.group
    group.set_pose_target(target_pose)
    # setGoalOrientationTolerance
    group.set_goal_orientation_tolerance(0.01)
    rospy.sleep(1)
    plan = group.go(wait=True)
    if not plan :
      print "go_to_pose_goal()------- slover can't find a plan baby......."
      arm_is_synced = True    # For debug version only
      return 

    # Calling `stop()` ensures that there is no residual movement
    group.stop()
    # It is always good to clear your targets after planning with poses.
    # Note: there is no equivalent function for clear_joint_value_targets()
    group.clear_pose_targets()

    # For testing:
    # Note that since this section of code will not be included in the tutorials
    # we use the class variable rather than the copied state variable

    current_pose = self.group.get_current_pose().pose
    # return all_close(pose_goal, current_pose, 0.01)

    arm_is_synced = False
    hand_in_world_x = target_pose.pose.position.x
    hand_in_world_y = target_pose.pose.position.y
    hand_in_world_z = target_pose.pose.position.z

    if wait_for_syncing:
      # print ">",
      timer = 0
      while not arm_is_synced:
        print "~",
        # rospy.spin()    # blocking others?
        rospy.sleep(1)
        # time.sleep(1)
        timer += 1
        if timer > 20:
          arm_is_synced= True
          print "go_to_pose_goal()   timeout->forced synced "

  def GetCurrentPose(self):
    group = self.group
    current_pose = self.group.get_current_pose().pose
    print "--------------current_pose.oreintation: ",current_pose
    '''

    '''

  def plan_cartesian_path(self, scale=1):
    print "------------------- start plan_cartesian_path()"
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good
    # reason not to.
    group = self.group

    ## BEGIN_SUB_TUTORIAL plan_cartesian_path
    ##
    ## Cartesian Paths
    ## ^^^^^^^^^^^^^^^
    ## You can plan a Cartesian path directly by specifying a list of waypoints
    ## for the end-effector to go through:
    ##
    waypoints = []

    wpose = group.get_current_pose().pose
    wpose.position.z -= scale * 0.05  # First move up (z)
    wpose.position.y += scale * 0.1  # and sideways (y)
    waypoints.append(copy.deepcopy(wpose))

    wpose.position.x += scale * 0.1  # Second move forward/backwards in (x)
    waypoints.append(copy.deepcopy(wpose))

    wpose.position.y -= scale * 0.05  # Third move sideways (y)
    waypoints.append(copy.deepcopy(wpose))

    # We want the Cartesian path to be interpolated at a resolution of 1 cm
    # which is why we will specify 0.01 as the eef_step in Cartesian
    # translation.  We will disable the jump threshold by setting it to 0.0 disabling:
    (plan, fraction) = group.compute_cartesian_path(
                                       waypoints,   # waypoints to follow
                                       0.05,        # eef_step
                                       0.0)         # jump_threshold

    # Note: We are just planning, not asking move_group to actually move the robot yet:
    return plan, fraction

    ## END_SUB_TUTORIAL

  def display_trajectory(self, plan):
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good
    # reason not to.
    robot = self.robot
    display_trajectory_publisher = self.display_trajectory_publisher

    ## BEGIN_SUB_TUTORIAL display_trajectory
    ##
    ## Displaying a Trajectory
    ## ^^^^^^^^^^^^^^^^^^^^^^^
    ## You can ask RViz to visualize a plan (aka trajectory) for you. But the
    ## group.plan() method does this automatically so this is not that useful
    ## here (it just displays the same trajectory again):
    ##
    ## A `DisplayTrajectory`_ msg has two primary fields, trajectory_start and trajectory.
    ## We populate the trajectory_start with our current robot state to copy over
    ## any AttachedCollisionObjects and add our plan to the trajectory.
    display_trajectory = moveit_msgs.msg.DisplayTrajectory()
    display_trajectory.trajectory_start = robot.get_current_state()
    display_trajectory.trajectory.append(plan)
    # Publish
    display_trajectory_publisher.publish(display_trajectory);

    ## END_SUB_TUTORIAL

  def execute_plan(self, plan):
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good
    # reason not to.
    group = self.group
    group.execute(plan, wait=True)

    ## **Note:** The robot's current joint state must be within some tolerance of the
    ## first waypoint in the `RobotTrajectory`_ or ``execute()`` will fail

  def wait_for_state_update(self, box_is_known=False, box_is_attached=False, timeout=4):
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good
    # reason not to.
    box_name = self.box_name
    scene = self.scene

    ## BEGIN_SUB_TUTORIAL wait_for_scene_update
    ##
    ## Ensuring Collision Updates Are Receieved
    ## ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    ## If the Python node dies before publishing a collision object update message, the message
    ## could get lost and the box will not appear. To ensure that the updates are
    ## made, we wait until we see the changes reflected in the
    ## ``get_known_object_names()`` and ``get_known_object_names()`` lists.
    ## For the purpose of this tutorial, we call this function after adding,
    ## removing, attaching or detaching an object in the planning scene. We then wait
    ## until the updates have been made or ``timeout`` seconds have passed
    start = rospy.get_time()
    seconds = rospy.get_time()
    while (seconds - start < timeout) and not rospy.is_shutdown():
      # Test if the box is in attached objects
      attached_objects = scene.get_attached_objects([box_name])
      is_attached = len(attached_objects.keys()) > 0

      # Test if the box is in the scene.
      # Note that attaching the box will remove it from known_objects
      is_known = box_name in scene.get_known_object_names()

      # Test if we are in the expected state
      if (box_is_attached == is_attached) and (box_is_known == is_known):
        return True

      # Sleep so that we give other threads time on the processor
      rospy.sleep(0.1)
      seconds = rospy.get_time()

    # If we exited the while loop without returning then we timed out
    return False
    ## END_SUB_TUTORIAL

  def add_box(self, timeout=4):
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good
    # reason not to.
    box_name = self.box_name
    scene = self.scene

    ## BEGIN_SUB_TUTORIAL add_box
    ##
    ## Adding Objects to the Planning Scene
    ## ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    ## First, we will create a box in the planning scene at the location of the left finger:
    box_pose = geometry_msgs.msg.PoseStamped()
    box_pose.header.frame_id = "ee_link"
    box_pose.pose.orientation.w = 1.0
    box_name = "box"
    scene.add_box(box_name, box_pose, size=(0.1, 0.1, 0.1))

    ## END_SUB_TUTORIAL
    # Copy local variables back to class variables. In practice, you should use the class
    # variables directly unless you have a good reason not to.
    self.box_name=box_name
    return self.wait_for_state_update(box_is_known=True, timeout=timeout)


  def attach_box(self, timeout=4):
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good
    # reason not to.
    box_name = self.box_name
    robot = self.robot
    scene = self.scene
    eef_link = self.eef_link
    group_names = self.group_names

    ## BEGIN_SUB_TUTORIAL attach_object
    ##
    ## Attaching Objects to the Robot
    ## ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    ## Next, we will attach the box to the MARA's EndEffector. Manipulating objects requires the
    ## robot be able to touch them without the planning scene reporting the contact as a
    ## collision. By adding link names to the ``touch_links`` array, we are telling the
    ## planning scene to ignore collisions between those links and the box. For the MARA
    ## robot, we set ``grasping_group = 'endeffector'``. If you are using a different robot,
    ## you should change this value to the name of your end effector group name.
    grasping_group = 'endeffector'
    touch_links = robot.get_link_names(group=grasping_group)
    scene.attach_box(eef_link, box_name, touch_links=touch_links)
    ## END_SUB_TUTORIAL

    # We wait for the planning scene to update.
    return self.wait_for_state_update(box_is_attached=True, box_is_known=False, timeout=timeout)

  def detach_box(self, timeout=4):
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good
    # reason not to.
    box_name = self.box_name
    scene = self.scene
    eef_link = self.eef_link

    ## BEGIN_SUB_TUTORIAL detach_object
    ##
    ## Detaching Objects from the Robot
    ## ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    ## We can also detach and remove the object from the planning scene:
    scene.remove_attached_object(eef_link, name=box_name)
    ## END_SUB_TUTORIAL

    # We wait for the planning scene to update.
    return self.wait_for_state_update(box_is_known=True, box_is_attached=False, timeout=timeout)

  def remove_box(self, timeout=4):
    # Copy class variables to local variables to make the web tutorials more clear.
    # In practice, you should use the class variables directly unless you have a good
    # reason not to.
    box_name = self.box_name
    scene = self.scene

    ## BEGIN_SUB_TUTORIAL remove_object
    ##
    ## Removing Objects from the Planning Scene
    ## ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    ## We can remove the box from the world.
    scene.remove_world_object(box_name)

    ## **Note:** The object must be detached before we can remove it from the world
    ## END_SUB_TUTORIAL

    # We wait for the planning scene to update.
    return self.wait_for_state_update(box_is_attached=False, box_is_known=False, timeout=timeout)

pub_arm = rospy.Publisher('arm_command', move_arm,queue_size=10)
pub_eef = rospy.Publisher('eef_command',eef,queue_size=10)

class Arduino_bridge():
  def __init__(self):
    self.arm_command = move_arm()
    # Initial movement.
    self.arm_command.joint1 = 0
    self.arm_command.joint2 = 0
    self.arm_command.joint3 = 0
    self.arm_command.joint4 = 0
    self.arm_command.joint5 = 0
    # self.robot_command.do_suck = False
    self.eef_command = eef()
    self.eef_command.action = 0   # how to write in enumerator?


    # ratio[0] In msg.jont2: 88.0 , Big wheel Single 42mm motor.
    # ratio[1] In msg.joint3: 12.05 , Dual 57mm motor
    # ratio[2] In msg.joint4: 230 , Single 42mm gearbox motor
    # ratio[3] In msg.joint5: 40,  Single 35mm motor
    # ratio[4] In msg.joint1: 63.8,  Linear motion.
    # decript a steps per degree.
    self.ratio = [90, 12.05, 230.0, 39.3, 63.8]   

  def publish_message_for_calibration_only(self):
    '''
    for calibrate a certain joint.
    target_joint is hard coded.
    '''
    do_suck = False
    while True:
      target_degree = float(raw_input("input target angle ..."))
      # print "ratio:",self.ratio

      self.robot_command.joint1 = 0 # target_degree * self.ratio[4]     # actual name is target_mm   
      self.robot_command.joint2 = 0 #  target_degree * self.ratio[0] 
      self.robot_command.joint3 = -0.5 # target_degree * self.ratio[1]    #dual 57mm steper motor
      self.robot_command.joint4 = -0.25 # target_degree * self.ratio[2]    
      self.robot_command.joint5 =   target_degree * self.ratio[3]

      # do_suck = not do_suck
      self.robot_command.do_suck = do_suck
      pub.publish(self.robot_command)   # The subscriber will be rosserial.
        
  def publish_message_to_hand(self,eef_action):
      '''
      '''
      self.eef_command.action = eef_action
      pub_eef.publish(self.eef_command)   # The subscriber will be rosserial.

  def real_state_callback(self,real_state):
    self.__real_state.joint3 =  real_state.joint3
    # print "received from arduino <--  ",real_state.joint3

  def arduino_callback(self,the_report):
    global arm_is_synced
    arm_is_synced = True
    print "                                           <<<<<<< arduino_callback, arm position synced"

  def moveit_transform_callback(self,received_fake_controller_joint_states):
    '''
    receiver a message from moveit_fake_controller, joint angle in radious.
    convert the angle to steps,then publish the steps to arduino.
    '''
    __RAD_TO_DEG = 180.0 / 3.14159265
    # print "target potiontion[1] for steps[] " , received_fake_controller_joint_states.position[1] * __RAD_TO_DEG
    # print "target potiontion[2]: " , received_fake_controller_joint_states.position[2] * __RAD_TO_DEG
    # print "target potiontion[4]: " , received_fake_controller_joint_states.position[4] * __RAD_TO_DEG
    # print "target potiontion[5]: " , received_fake_controller_joint_states.position[5] * __RAD_TO_DEG

    self.arm_command.joint1 = 0    # moveit has no linear motion right now.
    self.arm_command.joint2 = received_fake_controller_joint_states.position[0]  * self.ratio[0] * __RAD_TO_DEG
    self.arm_command.joint3 = (received_fake_controller_joint_states.position[1] - 0.5*pi /180) * self.ratio[1] * __RAD_TO_DEG
    self.arm_command.joint4 = (received_fake_controller_joint_states.position[2] - 0.25*pi /180)*  self.ratio[2] * __RAD_TO_DEG
    ############################################################    position[3]  always has no output right now.
    self.arm_command.joint5 = received_fake_controller_joint_states.position[4] * self.ratio[3] * __RAD_TO_DEG

    pub_arm.publish(self.arm_command)   # The subscriber will be rosserial_python/serial_node.py, then arduino
    self.robot_position_synced = False

lower_bridge = Arduino_bridge()
robot_arm = MoveGroupPythonIntefaceTutorial()

def start_lower_bridge():

  rospy.Subscriber('/move_group/fake_controller_joint_states', JointState, lower_bridge.moveit_transform_callback)
  rospy.Subscriber("/perfect_arm_report",report,lower_bridge.arduino_callback)

  # pub.publish(ab.robot_command)

  # rospy.spin()   #?????????????????????????????????????????? Will this block the process ??


class Chessboard():
  '''
  bottom-left point is [0,0] 
  center point is [9,9] 
  '''

  def __init__(self):
    self.CELL_LENGTH = 0.018 
    self.BASE_LINE_Y_DISTANCE = -0.225
    self.CENTER_INDEX = 9
    self._CHESSBOARD_Z = 0.18  # 0.024

  def to_robot_cordinator(self,target_X, target_Y):
    x = self.CELL_LENGTH * (self.CENTER_INDEX - target_X )
    y = - self.CELL_LENGTH * target_Y  + self.BASE_LINE_Y_DISTANCE
    z = self._CHESSBOARD_Z
    # print "Chessboard::to_robot_cordinator() result= ",x,y,z
    return x,y,z
  
  def get_trash_position(self):
    x,y,z = self.to_robot_cordinator(22, self.CELL_LENGTH)
    z = 0.30
    return x,y,z

BOARD = Chessboard()

class Tester():
  def __init__(self):
    pass

  def drop_to_trash(self):
    global eef
    print 'drop_to_trash()'
    # move to trash position
    x,y,z = BOARD.get_trash_position()
    target_postion = robot_arm.create_pose_with_head_down(x,y,z)
    robot_arm.go_to_pose_goal(target_postion,wait_for_syncing=True)

    # release chessman, then sucker goes to sleep
    lower_bridge.publish_message_to_hand(2)
    rospy.sleep(1)
    lower_bridge.publish_message_to_hand(3)

  def pick_place_chessman(self,action):
    '''
    going down, 5mm
    pick chessman
    going up, 5mm
    '''
    global hand_in_world_x
    global hand_in_world_y
    global hand_in_world_z
    # global eef_acktion
    # suck= true , going lower 5mm
    if action == 1:
      lower_bridge.publish_message_to_hand(1)   # 1 == pick,  2 == release

    target_postion = robot_arm.create_pose_with_head_down(hand_in_world_x ,hand_in_world_y, hand_in_world_z -0.02)
    print "pick_chessman() -----moving lower 5mm "
    robot_arm.go_to_pose_goal(target_postion,wait_for_syncing=True)

    if action == 2:
      lower_bridge.publish_message_to_hand(2)   

    # robot arm is synced, now move upper 5mm
    target_postion = robot_arm.create_pose_with_head_down(hand_in_world_x ,hand_in_world_y, hand_in_world_z + 0.02)
    print "place_chessman() ------- movint upper 5mm "
    robot_arm.go_to_pose_goal(target_postion,wait_for_syncing=True)
    
    if action == 2:
      lower_bridge.publish_message_to_hand(0)

  def play_on_one_way(self,from_points, to_points):
    i = 0
    while i < from_points.__len__():
      board_x = from_points[i][0]
      board_y = from_points[i][1]
      print "-------------",board_x,board_y
      x,y,z = BOARD.to_robot_cordinator(board_x, board_y)
      target_pose = robot_arm.create_pose_with_head_down(x,y,z)
      # print "*************  ",target_pose
      robot_arm.go_to_pose_goal(target_pose, wait_for_syncing=True)
      # self.pick_place_chessman(eef_acktion('EEF_PICK'))

      self.pick_place_chessman(1)

      board_x = to_points[i][0]
      board_y = to_points[i][1]
      x,y,z = BOARD.to_robot_cordinator(board_x, board_y)
      print "-------------",board_x,board_y
      target_pose = robot_arm.create_pose_with_head_down(x,y,z)
      robot_arm.go_to_pose_goal(target_pose,wait_for_syncing=True)
      self.pick_place_chessman(2)

      i += 1

  def play_A(self):
    points_a =[[9,17], [9,16], [9,15], [9,14], [9,13], [9,12], [9,11], [9,10], [9,9],  [9,8],  [9,7], [9,6]]
    points_b =[[0,8],  [2,8],  [4,8],  [6,8],  [8,8],  [10,8], [12,8], [14,8], [16,8], [18,8], [8,7], [10,7] ]
    while True:
      self.play_on_one_way(points_a,points_b)
      self.play_on_one_way(points_b,points_a)

  def calibrate(self):
    points = [[3,3],[3,9],[3,15],[9,15],[9,9],[9,3],[15,3],[15,9],[15,15],[9,9]]
    i = 0
    while i < points.__len__():
      board_x = points[i][0]
      board_y = points[i][1]
      print "-------------",board_x,board_y
      x,y,z = BOARD.to_robot_cordinator(board_x, board_y)
      z += 0.018
      target_pose = robot_arm.create_pose_with_head_down(x,y,z)
      # print "*************  ",target_pose
      robot_arm.go_to_pose_goal(target_pose, wait_for_syncing=True)

      self.pick_place_chessman(0)
      i += 1

  def draw_line_on_Y(self, align_X,sleep_second):
    board_y = 18
    while board_y > 0:
      x,y,z = BOARD.to_robot_cordinator(align_X, board_y)

      target_postion = robot_arm.create_pose_with_head_down(x,y,z)
      print "sleeping 10 seconds --------------- I am moving to : [x,y]",align_X,',', board_y
      print target_postion

      robot_arm.go_to_pose_goal(target_postion)
      # cartesian_plan, fraction = tutorial.plan_cartesian_path()
      # tutorial.display_trajectory(cartesian_plan)
      # tutorial.execute_plan(cartesian_plan)
      rospy.sleep(sleep_second)

  def draw_line_on_Y_remove_all(self, align_X):
    print "================================================================================"
    board_y = 17
    while board_y > 0:
      x,y,z = BOARD.to_robot_cordinator(align_X, board_y)
      y = -y

      target_postion = robot_arm.create_pose_with_head_down(x,y,z)
      print "draw_line_on_Y_remove_all()  --------------- I am moving to : [x,y]",align_X,',', board_y
      print "target_postion: "  ,target_postion
      robot_arm.go_to_pose_goal(target_postion,wait_for_syncing=True)

      self.pick_place_chessman(action = 1)
      self.drop_to_trash()
      board_y -= 1

  def draw_line_on_X(self, align_y,sleep_second):
    board_x = 0
    while board_x < 19:
      x,y,z = BOARD.to_robot_cordinator(board_x,align_y)
      target_postion = robot_arm.create_pose_with_head_down(x,y,z)
      print "sleeping 10 seconds --------------- I am moving to this point: "
      print target_postion

      robot_arm.go_to_pose_goal(target_postion)
      # cartesian_plan, fraction = tutorial.plan_cartesian_path()
      # tutorial.display_trajectory(cartesian_plan)
      # tutorial.execute_plan(cartesian_plan)
      rospy.sleep(sleep_second)
      board_x += 1
      

  def draw_spinout(self, sleep_second):
    r = 0
    while r < 10:
      xx = int( math.sin(r*pi/2)) * r + 9
      yy = int( math.cos(r*pi/2)) * r + 9
      x,y,z = BOARD.to_robot_cordinator( xx, yy)
      print "spin_out [x,y]= [",xx, ',',yy,']'
      print "robot pos [x,y,z]= [",x, ',',y,',',z,']'
      target_postion = robot_arm.create_pose_with_head_down(x,y,z)
      robot_arm.go_to_pose_goal(target_postion)
      rospy.sleep(sleep_second)

      r += 1

  def draw_left_center_right_center(self):
    # temp = raw_input ("press any key to continue.....")
    chessboard = Chessboard()
    x,y,z = chessboard.to_robot_cordinator(0,9)
    target_postion = robot_arm.create_pose_with_head_down(x,y,z)
    robot_arm.go_to_pose_goal(target_postion)
    rospy.sleep(5)

    x,y,z = chessboard.to_robot_cordinator(9,9)
    target_postion = robot_arm.create_pose_with_head_down(x,y,z)
    robot_arm.go_to_pose_goal(target_postion)
    rospy.sleep(5)        

    x,y,z = chessboard.to_robot_cordinator(18,9)
    target_postion = robot_arm.create_pose_with_head_down(x,y,z)
    robot_arm.go_to_pose_goal(target_postion)
    rospy.sleep(5)

    x,y,z = chessboard.to_robot_cordinator(9,9)
    target_postion = robot_arm.create_pose_with_head_down(x,y,z)
    robot_arm.go_to_pose_goal(target_postion)
    rospy.sleep(5)

def main():
  rospy.init_node('middleware', anonymous=True)
  start_lower_bridge()
  # lower_bridge.publish_message_for_calibration_only()
  print("Opencv version: ",cv.__version__)

  tester = Tester()
  while True:
    tester.calibrate()
  # tester.draw_line_on_X(9,sleep_second = 5)
  # tester.draw_line_on_Y_remove_all(9)
  # tester.draw_spinout(sleep_second = 5)

if __name__ == '__main__':
  main()
