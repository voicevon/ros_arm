#!/usr/bin/env python
# coding=utf-8

#  The exlaination is here:
#  http://docs.ros.org/kinetic/api/moveit_tutorials/html/doc/move_group_python_interface/move_group_python_interface_tutorial.html
import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import pi
from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list

# Socket Server
import socket   # socket模块

# ROS ServiceClient
from faze4.srv._JointTrajectory import *
from faze4.srv._GripperCommand import *


class Faze4Client:
    def __init__(self):
        pass

    def follow_joint_position(self, x, y, z):
        SERVICE_NAME = 'JointPosition'

        rospy.wait_for_service(SERVICE_NAME)  # will block?
        try:
            server = rospy.ServiceProxy(SERVICE_NAME, FollowJointPosition)
            response = server(x, y, z)
        except rospy.ServiceException, e:
            print "Service call failed: %s %e"

    def follow_gripper_command(self, action):
        SERVICE_NAME = 'GripperCommand'

        rospy.wait_for_service(SERVICE_NAME)  # will block?
        try:
            server = rospy.ServiceProxy(SERVICE_NAME, GripperCommand)
            response = server(action)
        except rospy.ServiceException, e:
            print "Service call failed: %s %e"


class MoveIt:
    def __init__(self):
        self.__group_name = "arm"
        self.__connect_to_moveit()

    def __connect_to_moveit(self):
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('move_group_python_interface_tutorial',
                        anonymous=True)
        self.__robot = moveit_commander.RobotCommander()
        self.__scene = moveit_commander.PlanningSceneInterface()

        self.__moveit_group = moveit_commander.MoveGroupCommander(self.__group_name)

        self.__display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',
                                                    moveit_msgs.msg.DisplayTrajectory,
                                                    queue_size=20)   

    def go_joint(self):
        joint_goal = self.group.get_current_joint_values()
        joint_goal[0] = 1
        self.group.go(joint_goal, wait=True)

    def go_pose(self, x, y, z):
        pose_goal = geometry_msgs.msg.Pose()
        pose_goal.orientation.w = 1.0
        pose_goal.position.x = x
        pose_goal.position.y = y
        pose_goal.position.z = z

        self.__moveit_group.set_pose_target(pose_goal)
        self.__moveit_group.go()


class SocketListener:
    __my_socket_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)   # 定义socket类型，网络通信，TCP

    def __init__(self, port):
        self.__host = '127.0.0.1'
        self.__port = port
        self.start_listen()

    def start_listen(self):
        self.__my_socket_server.bind((self.__host, self.__port))   # 套接字绑定的IP与端口
        self.__my_socket_server.listen(1)         # 开始TCP监听

    def disconnect(self):
        self.__connection.close()

    def read_received_buffer(self):
        connection, addr = self.__my_socket_server.accept()   # 接受TCP连接，并返回新的套接字与IP地址
        error = false
        try:
            data = self.__connection.recv(1024)    # 把接收的数据实例化
            if len(data) > 0:
                self.__connection.sendall(b"ok\n")
        except Exception:
            print("socket客户端中断了一次")
            print(Exception.value)
            error = True
        return error, data


class RobotController:
    def __init__(self):
        self.__moveit = MoveIt()
        self.__faze4_client = Faze4Client()
        self.__socket_listener = SocketListener(port=5000)

    def goto(self, x, y, z):
        self.__moveit.go_pose(x, y, z)

    def pick_place(self, action):
        self.__faze4_client.follow_gripper_command(action)

    def socket_listener_loop(self):
        while (1):
            error, data = self.__socket_listener.read_received_buffer()
            if error:
                self.__socket_listener.disconnect
                self.__socket_listener.start_listen()
            if len(data) > 0:
                commd = data.decode().split(":")
                if commd[0] == "moveto":
                    x, y, z = commd[1].split(",")
                    self.goto(x, y, z)

                elif commd[0] == "hand":
                    action = commd[1]
                    self.pick_place(action)

                elif commd[0] == "getposition":
                    pass
                else:
                    print("不知道的命令，不处理了")


class TesterSocket:
    def __init__(self):
        robot = RobotController()
        robot.socket_listener_loop()


class TesterApi:
    def __init__(self):
        robot = RobotController()
        robot.goto(-0.1, 0.1, 0.1)
        robot.pick_place(1)


# TesterSocket()
print ('Testing api')
TesterApi()
