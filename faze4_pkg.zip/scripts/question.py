#!/usr/bin/env python
from faze4.msg import joint_angle as faze4_joint_angle

print '\n It worked \n'
